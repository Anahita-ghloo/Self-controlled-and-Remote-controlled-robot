package com.example.myapplication.Controls;

import android.util.Log;
import android.widget.ImageButton;

import com.example.myapplication.R;
import com.example.myapplication.UI.MainActivity;

public class MovementControl {

    int imgId;
    String cmdText = null;

    public MovementControl(int id){
        imgId = id;
    }

    public String getArduinoCommand(){


        switch (imgId){
            case R.id.forward :
                cmdText = "<forward>";
                break;
            case R.id.backward :
                cmdText = "<backward>";
                break;
            case R.id.right :
                cmdText = "<right>";
                break;
            case R.id.left :
                cmdText = "<left>";
                break;
            case R.id.auto :
                auto_remote_mood ();
                break;
        }

        return cmdText;
    }


    public void auto_remote_mood () {

        if (!MainActivity.auto) {
            // Change to SElf-controlled mood
            MainActivity.auto = true;
            MainActivity.btnAuto.setImageResource(R.drawable.ic_remote_control);
            MainActivity.btnForward.setEnabled(false);
            MainActivity.btnBackward.setEnabled(false);
            MainActivity.btnLeft.setEnabled(false);
            MainActivity.btnRight.setEnabled(false);
            cmdText = "<auto>";
        }
        else {
            // Change to Remote-controlled mood
            MainActivity.auto = false;
            MainActivity.btnAuto.setImageResource(R.drawable.ic_auto_control);
            MainActivity.btnForward.setEnabled(true);
            MainActivity.btnBackward.setEnabled(true);
            MainActivity.btnLeft.setEnabled(true);
            MainActivity.btnRight.setEnabled(true);
            cmdText = "<remote>";
        }
    }
}
