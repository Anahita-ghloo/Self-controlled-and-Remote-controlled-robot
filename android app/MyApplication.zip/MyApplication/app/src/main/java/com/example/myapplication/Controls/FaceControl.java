package com.example.myapplication.Controls;

public class FaceControl {

    int emojiPosition;

    public FaceControl(int position){
        emojiPosition = position;
    }

    public String getArduinoCommand(){

        String cmdText = null;

        switch (emojiPosition){
            case 0 :
                cmdText = "<smile>";
                break;
            case 1 :
                cmdText = "<sad>";
                break;
            case 2 :
                cmdText = "<cross>";
                break;
            case 3 :
                cmdText = "<poker>";
                break;
            case 4 :
                cmdText = "<surprised>";
                break;
        }

        return cmdText;
    }
}
